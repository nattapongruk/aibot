1.run พิมพ์ %appdata%
2.หา folder MetaQuotes/Terminal/.../MQL4/... แล้วนำ folder Include Libraries และ Expert ไปใส่ใน folder นั้น
3.หา folder MetaQuotes/Terminal/.../tester นำไฟล์ .set ไปใส่ใน folder นี้